# nvimconfig
My nvim configuration
